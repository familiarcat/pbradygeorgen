/* eslint-disable no-undef */
// const models = initSchema(schema)

module.exports = {
  models: {
    Reference: {
      name: "Reference",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        name: {
          name: "name",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        phone: {
          name: "phone",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        email: {
          name: "email",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        contactinformationID: {
          name: "contactinformationID",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "References",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byContactInformation",
            fields: ["contactinformationID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    ContactInformation: {
      name: "ContactInformation",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        name: {
          name: "name",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        email: {
          name: "email",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        phone: {
          name: "phone",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        References: {
          name: "References",
          isArray: true,
          type: {
            model: "Reference",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["contactinformationID"],
          },
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "ContactInformations",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Resume: {
      name: "Resume",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        Summary: {
          name: "Summary",
          isArray: false,
          type: {
            model: "Summary",
          },
          isRequired: false,
          attributes: [],
          association: {
            connectionType: "HAS_ONE",
            associatedWith: ["id"],
            targetNames: ["resumeSummaryId"],
          },
        },
        Skills: {
          name: "Skills",
          isArray: true,
          type: {
            model: "Skill",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["resumeID"],
          },
        },
        Education: {
          name: "Education",
          isArray: false,
          type: {
            model: "Education",
          },
          isRequired: false,
          attributes: [],
          association: {
            connectionType: "HAS_ONE",
            associatedWith: ["id"],
            targetNames: ["resumeEducationId"],
          },
        },
        Experience: {
          name: "Experience",
          isArray: false,
          type: {
            model: "Experience",
          },
          isRequired: false,
          attributes: [],
          association: {
            connectionType: "HAS_ONE",
            associatedWith: ["id"],
            targetNames: ["resumeExperienceId"],
          },
        },
        ContactInformation: {
          name: "ContactInformation",
          isArray: false,
          type: {
            model: "ContactInformation",
          },
          isRequired: false,
          attributes: [],
          association: {
            connectionType: "HAS_ONE",
            associatedWith: ["id"],
            targetNames: ["resumeContactInformationId"],
          },
        },
        title: {
          name: "title",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        resumeSummaryId: {
          name: "resumeSummaryId",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        resumeEducationId: {
          name: "resumeEducationId",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        resumeExperienceId: {
          name: "resumeExperienceId",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        resumeContactInformationId: {
          name: "resumeContactInformationId",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
      },
      syncable: true,
      pluralName: "Resumes",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Education: {
      name: "Education",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        summary: {
          name: "summary",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        Schools: {
          name: "Schools",
          isArray: true,
          type: {
            model: "School",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["educationID"],
          },
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Educations",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Degree: {
      name: "Degree",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        major: {
          name: "major",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        startYear: {
          name: "startYear",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        endYear: {
          name: "endYear",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        schoolID: {
          name: "schoolID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        School: {
          name: "School",
          isArray: false,
          type: {
            model: "School",
          },
          isRequired: false,
          attributes: [],
          association: {
            connectionType: "BELONGS_TO",
            targetNames: ["schoolID"],
          },
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Degrees",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "bySchool",
            fields: ["schoolID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Company: {
      name: "Company",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        name: {
          name: "name",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        role: {
          name: "role",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        startDate: {
          name: "startDate",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        endDate: {
          name: "endDate",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        historyID: {
          name: "historyID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        Engagements: {
          name: "Engagements",
          isArray: true,
          type: {
            model: "Engagement",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["companyID"],
          },
        },
        Accomplishments: {
          name: "Accomplishments",
          isArray: true,
          type: {
            model: "Accomplishment",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["companyID"],
          },
        },
        Skills: {
          name: "Skills",
          isArray: true,
          type: {
            model: "Skill",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["companyID"],
          },
        },
        title: {
          name: "title",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        gptResponse: {
          name: "gptResponse",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Companies",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byExperience",
            fields: ["historyID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Accomplishment: {
      name: "Accomplishment",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        title: {
          name: "title",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        description: {
          name: "description",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        link: {
          name: "link",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        engagementID: {
          name: "engagementID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        companyID: {
          name: "companyID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        Skills: {
          name: "Skills",
          isArray: true,
          type: {
            model: "Skill",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["accomplishmentID"],
          },
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Accomplishments",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byEngagement",
            fields: ["engagementID"],
          },
        },
        {
          type: "key",
          properties: {
            name: "byCompany",
            fields: ["companyID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    School: {
      name: "School",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        name: {
          name: "name",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        Degrees: {
          name: "Degrees",
          isArray: true,
          type: {
            model: "Degree",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["School"],
          },
        },
        educationID: {
          name: "educationID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Schools",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byEducation",
            fields: ["educationID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Experience: {
      name: "Experience",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        title: {
          name: "title",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        text: {
          name: "text",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        Companies: {
          name: "Companies",
          isArray: true,
          type: {
            model: "Company",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["historyID"],
          },
        },
        gptResponse: {
          name: "gptResponse",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Experiences",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Skill: {
      name: "Skill",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        title: {
          name: "title",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        link: {
          name: "link",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        resumeID: {
          name: "resumeID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        companyID: {
          name: "companyID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        accomplishmentID: {
          name: "accomplishmentID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Skills",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byResume",
            fields: ["resumeID"],
          },
        },
        {
          type: "key",
          properties: {
            name: "byCompany",
            fields: ["companyID"],
          },
        },
        {
          type: "key",
          properties: {
            name: "byAccomplishment",
            fields: ["accomplishmentID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Engagement: {
      name: "Engagement",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        client: {
          name: "client",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        startDate: {
          name: "startDate",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        endDate: {
          name: "endDate",
          isArray: false,
          type: "AWSDate",
          isRequired: false,
          attributes: [],
        },
        companyID: {
          name: "companyID",
          isArray: false,
          type: "ID",
          isRequired: false,
          attributes: [],
        },
        Accomplishments: {
          name: "Accomplishments",
          isArray: true,
          type: {
            model: "Accomplishment",
          },
          isRequired: false,
          attributes: [],
          isArrayNullable: true,
          association: {
            connectionType: "HAS_MANY",
            associatedWith: ["engagementID"],
          },
        },
        gptResponse: {
          name: "gptResponse",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Engagements",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "key",
          properties: {
            name: "byCompany",
            fields: ["companyID"],
          },
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
    Summary: {
      name: "Summary",
      fields: {
        id: {
          name: "id",
          isArray: false,
          type: "ID",
          isRequired: true,
          attributes: [],
        },
        goals: {
          name: "goals",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        persona: {
          name: "persona",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        url: {
          name: "url",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        headshot: {
          name: "headshot",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        gptResponse: {
          name: "gptResponse",
          isArray: false,
          type: "String",
          isRequired: false,
          attributes: [],
        },
        createdAt: {
          name: "createdAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
        updatedAt: {
          name: "updatedAt",
          isArray: false,
          type: "AWSDateTime",
          isRequired: false,
          attributes: [],
          isReadOnly: true,
        },
      },
      syncable: true,
      pluralName: "Summaries",
      attributes: [
        {
          type: "model",
          properties: {},
        },
        {
          type: "auth",
          properties: {
            rules: [
              {
                allow: "public",
                operations: ["create", "update", "delete", "read"],
              },
            ],
          },
        },
      ],
    },
  },
  enums: {},
  nonModels: {},
  codegenVersion: "3.4.4",
  version: "16929f616e047a148277404560131a64",
}
