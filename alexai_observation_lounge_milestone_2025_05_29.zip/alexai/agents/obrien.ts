// Agent: OBrien
export const obrienAgent = { name: 'OBrien', role: 'Interface & Transport Ops' };