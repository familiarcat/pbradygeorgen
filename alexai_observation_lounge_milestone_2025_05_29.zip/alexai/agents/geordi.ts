// Agent: Geordi
export const geordiAgent = { name: 'Geordi', role: 'Chief Engineer / Infra' };