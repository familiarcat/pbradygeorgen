// Agent: Spock
export const spockAgent = { name: 'Spock', role: 'Ambassador / Logic Anchor' };