// Agent: Troi
export const troiAgent = { name: 'Troi', role: 'Counselor / Retrospective Lead' };