// Agent: Crusher
export const crusherAgent = { name: 'Crusher', role: 'CMO / Health & Diagnostics' };