// Agent: Riker
export const rikerAgent = { name: 'Riker', role: 'First Officer / Tactical Execution' };