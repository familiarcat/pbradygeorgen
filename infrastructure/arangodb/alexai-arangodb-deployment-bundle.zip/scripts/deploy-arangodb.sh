#!/bin/bash

# Launch an EC2 instance with Docker and ArangoDB

KEY_NAME="AlexKeyPair"
INSTANCE_TYPE="t3.medium"
SECURITY_GROUP_NAME="AlexAI-ArangoDB-SG"
AMI_ID="ami-0c02fb55956c7d316"
REGION="us-east-1"
PEM_PATH="$HOME/.ssh/AlexKeyPair.pem"

# Create security group if not exists
aws ec2 describe-security-groups --group-names $SECURITY_GROUP_NAME --region $REGION 2>/dev/null || \
aws ec2 create-security-group --group-name $SECURITY_GROUP_NAME --description "Allow ArangoDB" --region $REGION

# Authorize port 8529 for ArangoDB
aws ec2 authorize-security-group-ingress --group-name $SECURITY_GROUP_NAME \
    --protocol tcp --port 8529 --cidr 0.0.0.0/0 --region $REGION 2>/dev/null || true

# Launch EC2 instance
aws ec2 run-instances --image-id $AMI_ID --count 1 --instance-type $INSTANCE_TYPE \
    --key-name $KEY_NAME --security-groups $SECURITY_GROUP_NAME --region $REGION \
    --user-data file://<(echo '#!/bin/bash
    apt update -y
    apt install docker.io -y
    systemctl start docker
    systemctl enable docker
    docker run -d -e ARANGO_ROOT_PASSWORD=secretpassword -p 8529:8529 --name arangodb arangodb/arangodb:latest')
