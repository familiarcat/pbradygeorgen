import { lcarsTokens } from "@/tokens/lcars-token-map";
// 🧱 LCARS Component System (Sample)
import React from 'react';
import { colors, spacing, fonts } from '@/tokens/lcars-token-map';

export function LcarsPanel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      backgroundColor: lcarsTokens.colors.lcarsBeige,
      padding: lcarsTokens.spacing.medium,
      fontFamily: lcarsTokens.fonts.primary,
      borderLeft: `12px solid ${lcarsTokens.colors.lcarsBlue}`
    }}>
      {children}
    </div>
  );
}