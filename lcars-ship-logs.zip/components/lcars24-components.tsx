import React from 'react';
import { tokens } from '../tokens/lcars-token-map';

export function LcarsHeader({ title }: { title: string }) {
  return (
    <header style={{
      fontFamily: tokens.font.heading,
      fontSize: '2rem',
      color: tokens.color.primary,
      padding: tokens.spacing.lg,
      borderBottom: `2px solid ${tokens.color.primary}`
    }}>
      {title}
    </header>
  );
}