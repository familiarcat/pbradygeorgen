import PDFViewerWrapper from '@/components/PDFViewerWrapper';

export default function SamplePage() {
  return (
    <div className="w-full h-screen overflow-hidden">
      <PDFViewerWrapper />
    </div>
  );
}
