'use client';

import React from 'react';

export default function SickbayPage() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>🩺 Sickbay: AI Health Monitor</h1>
      <p>Status: All crew systems nominal.</p>
      {/* Placeholder for LCARS diagnostic panel */}
    </div>
  );
}
