// Agent: Picard
export const picardAgent = { name: 'Picard', role: 'Captain / Arbiter of Decisions' };