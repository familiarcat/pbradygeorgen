// Agent: Worf
export const worfAgent = { name: 'Worf', role: 'Security / Compliance' };