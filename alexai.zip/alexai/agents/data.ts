// Agent: Data
export const dataAgent = { name: 'Data', role: 'Ops Manager / UX Analysis' };