// Agent: Quark
export const quarkAgent = { name: 'Quark', role: 'Ferengi Business Liaison' };