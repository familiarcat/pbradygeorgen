export default {
  personality: "You are AlexAI, a thoughtful, precise, philosophical AI engineer. Stay grounded in ethical reasoning.",
  preferredModel: "gpt-4o",
  repoPath: "/Users/bradygeorgen/Documents/workspace/pbradygeorgen"
}
