// Stub LangChain integration (to be connected to Chroma, Pinecone, or Weaviate)
export const getMemory = () => {
  return {
    decisions: [],
    notes: [],
  };
};
