# Benjamin Stein

**Contact:**  
+1 (314)-809-1836  
benjaminsteinstl@gmail.com  
St. Louis, MO

---

## Professional Summary
Dynamic Clinical Informatics Specialist with over a decade of experience in healthcare IT systems management, specializing in EHR implementation, clinical analysis, and staff training. Proven track record of optimizing EMR workflows, ensuring HIPAA compliance, and enhancing data accuracy. Skilled in leading cross-functional teams, interpreting reports, and driving operational efficiency within clinical settings.

---

## Work Experience

### Clinical Informatics Specialist  
**Homer G. Phillips Memorial Hospital**  
*St. Louis, MO*  
*MAR 2023 - Current*

- Spearheaded the implementation, maintenance, and training of the web-based EHR system (Thrive) and various enterprise applications.
- Managed on/off-boarding processes for office and clinical users, configuring securities, permissions, and liaising with third-party vendors.
- Conducted troubleshooting analysis on EMR, network, hardware, and web applications, ensuring seamless operations.
- Generated custom reports using the TruBridge Report Builder, contributing to data-driven decision-making.

### Clinical Analyst II  
**Shriners Hospital for Children**  
*St. Louis, MO*  
*MAR 2018 - MAR 2023*

- Led the implementation of new functionalities within the Cerner suite, providing training and support to clinical staff.
- Designed and interpreted reports in SAP Business Objects, enhancing data visualization and analysis capabilities.
- Managed PC maintenance schedules, ensuring optimal performance and security across the hospital's network.
- Tracked and resolved ticket issues using ServiceNow, streamlining IT support processes.

### Clinical Analyst I  
**Advanced ICU Care**  
*St. Louis, MO*  
*APR 2012 - FEB 2015*

- Supported 24x7 IT operations for clinical staff, resolving hardware, OS, and application issues promptly.
- Monitored and maintained health information integration engines, ensuring seamless data exchange.
- Provided remote support to clinical staff in different locations, optimizing eCare integration and system performance.
- Configured virtual A/V servers for enhanced telemedicine capabilities, contributing to improved patient care outcomes.

---

## Skills

### Technical Skills
- EHR Implementation
- EMR Analysis
- Data Reporting (TruBridge, SAP Business Objects)
- HIPAA Compliance
- HL7 Integration
- Epic & Cerner Systems
- Meditech Applications

### Soft Skills
- Team Leadership
- Training & Development
- Communication
- Problem-Solving
- Project Management

---

## Education

- **Ranken Technical College**
  - Network & Database Administration
  - *2010 - 2012*

- **St. Louis Community College**
  - Graphic Communications
  - *2002 - 2005*

## Certifications

- M.C.T.S - Windows XP, VISTA, Server 08 R2, Active Directory, SQL
- CompTIA - A+
- Dell Certified Systems Expert
- Sony-certified - Laptop Repair
- HIPAA Certified

---

References available upon request.