# Homer G. Phillips Memorial Hospital

1320 N Jefferson Ave, St. Louis, MO 63106

Clinical Informatics Specialist

MAR 2023 - Current

Shriners Hospital for Children

4400 Clayton Ave, St. Louis, MO 6311

Clinical Analyst II


## MAR 2018 - MAR 2023

Advanced ICU Care

1 Cityplace Dr Suite 570 Suite 570, St. Louis, MO 63141

Clinical Analyst I


## APR 2012 - FEB 2015

As one of the first employees hired at Homer G. Phillips Memorial

Hospital, myself and the CISO are solely responsible for all systems

and technologies used at the hospital, Implementation, maintenance,

and training of our web-based EHR system(Thrive), Enterprise web

browser (Island), Google Enterprise, Administrative roles within

Panorama 9, Verkada, SiPass, Zendesk,IT Glue, Chartnote. Typical

tasks would include the On/Off-boarding of all office and clinical users.

Configuring securities and permissions for each user. Communicating

with third party vendors, trouble-shooting analysis related to the EMR,

Network, Interfaces, PC’s, Hardware, and Web Applications.

Creating, modifying, or running reports as needed via the TruBridge

Report Builder.


## BENJAMIN STEIN


## WORK EXPERIENCE


## CLINICAL INFORMATICS SPECIALIST

2143 Alfred Ave. St. Louis, MO. 63110

+1 (314)-809-1836          benjaminsteinstl@gmail.com

Experience extended:

Education:

Certifications:

M.C.T.S - Windows Xp


## M.C.T.S - VISTA

M.C.T.S - Server 08 R2

M.C.T.S - Active Directory


## M.C.T.S - SQL

CompTIA - A+

Dell Certified Systems Expert

Sony-certified - laptop repair

HIPAA Certified

References:

Provide day-to-day support for the entire clinical and office staff,

Lead / Participate in the implementation of new functionality within the

Cerner suite (PowerChart, Surginet, Anesthesia Module etc.), Provide

training and access for any newly on boarded clinical staff, Design and

interpret reports in SAP Business Objects, and Discern Analytics. Develop

training material as needed, Track tickets issues using Service Now.

Maintain an active maintenance schedule of all PC’s in the hospital,

Manage user sessions with Citrix Desktop Director.

At AICU, I was one of four analysts responsible for providing 24x7 IT support

for theclinical staff of the largest provider of tele-ICU services in the nation.

Areas of support included: Hardware and OS issues. Applications associat-

ed with various hospital health Information systems such as Epic, Meditech,

and Mindray, Monitoring and Maintaining health information integration

engines, such as Corepoint and Rapsody/Orion, including management

and manipulation of HL7 messages, VPN repair and eCare integration,

Remote support of NY and India clinical staff via Simple-Help remote

desktop, Creation/configuration of virtual A/V servers, such as Vidyo, STI,

and Axis.

Karen Johnson

C.E.O.Homer G. Phillips Memorial

Hospital


## +1 (314) 399-4288

Susan “Angie” Kinney

Clinical Analyst II

Shriners Hospital for Children


## +1 (618) 960-5628

Justin Thuli

Manager of I.T.

Advanced ICU Care


## +1 (608) 215-9302

Ranken Technical College


## 2010 - 2012

Network & Database Administration

St. Louis Community College


## 2002 - 2005

Graphic Communications

Boeing

Under Contract by RMS

IT Specialist - 2/17 - 2/18

Baked Tees

Graphic Designer - 4/11 - 4/12

Tek Systems

IT Specialist - 3/10 - 9/10

Nexicore Technology

Mobile Technician - 4/09 - 11/09

Think Tank Design

Graphic Designer - 2/07

